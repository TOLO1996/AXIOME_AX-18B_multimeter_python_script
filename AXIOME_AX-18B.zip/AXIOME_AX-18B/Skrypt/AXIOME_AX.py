#!/usr/bin/python2.7
 
#
#   Just a quick n' dirty script to read the Data from a VA18B multimeter.
#   This DMM uses the low nibble of 14 bytes to send the lcd segments.
#
#       License: GPL v3. http://www.gnu.org/licenses/gpl-3.0-standalone.html
#
 
import signal
import sys
import time
import serial
import io
import getopt
 
interval = '1.0'
device = '/dev/ttyUSB0'
 
 
#def showhelp():
   # print (va18b.py -i <time in secs> -d <device>")
   # print '   Eg:  va18b.py -i 1.5 -d /dev/ttyUSB1'
     
     
try:
    opts, args = getopt.getopt(sys.argv[1:],"hd:i:",['help'])
except getopt.GetoptError:
   # print 'Error: -i, -d option require a value.'
    #showhelp()
    sys.exit(1)
         
for opt, arg in opts:
    if opt in ('-h','--help'):
      #showhelp()
      sys.exit(1)
    if opt == '-i':
      interval = arg
    if opt == '-d':
      device = arg
       
try:

    port=serial.Serial('COM38',
               baudrate=2400,
               bytesize=serial.EIGHTBITS,
               stopbits=serial.STOPBITS_ONE,
               parity=serial.PARITY_NONE,
               timeout=None)
     
    if not port.isOpen():
        port.open()
 
except IOError:
    #print '\nError:' + str(err) + '\n'
    sys.exit(1)
 
 
def signal_handler(signal, frame):
        sys.stderr.write('\n\nYou pressed Ctrl+C!\n\n')
        port.flushInput()
        port.close()
        sys.exit(0)
         
signal.signal(signal.SIGINT, signal_handler)
 
# Every packet is 14 bytes long.
def get_bytes():
    i=0
    substr=''
    while i<=13:
        byte=port.read(1)
        # converting every byte to binary format keeping the low nibble.
        substr += '{0:08b}'.format(ord(byte))[4:]
        i += 1
    return substr
       
def add_spaces(input_string):

    # Definiujemy długości segmentów
    segment_lengths = [7,1, 7, 1, 7, 1, 7, 1,7,17]
    segments = []
    index = 0
    
    for length in segment_lengths:
        # Dodajemy segment do listy
        segments.append(input_string[index:index+length])
        # Przesuwamy indeks o długość segmentu
        index += length

    # Join the chunks with a space
    spaced_string = ' '.join(segments)
    return spaced_string

def display_string_table(input_string):
    # Create a table with index and character value
    table = []
    for i, char in enumerate(input_string):
        table.append((i, char))
    
    # Print the table
    print("Index\tCharacter")
    for index, char in table:
        print(f"{index}\t{char}")

def display_string_table_horizontal(input_string):
    # Create a table with index and character value
    table = []
    for i, char in enumerate(input_string):
        table.append((i, char))
    
    # Print the table horizontally with indices above characters
    index_row = "Index:\t" + " ".join(str(index) for index, _ in table)
    char_row = "Character:\t" + " ".join(char for _, char in table)
    
    print(index_row)
    print(char_row)

def add_spaces_between_characters(input_string):
    # Dodaj spację między każdym znakiem
    spaced_string = ' '.join(input_string)
    return spaced_string

def add_spaces_every_8_chars(input_string):
    # Initialize an empty result string
    result = ""
    
    # Loop through the input string in steps of 8
    for i in range(0, len(input_string), 8):
        # Add the next 8 characters and a space to the result string
        result += input_string[i:i+8] + " "
    
    # Print the result string
    #print(result.strip())
    return result.strip()
def stream_decode(substr):
   
    ac       = int(substr[0:1])
    dc       = int(substr[1:2])
    auto     = int(substr[2:3])
    pclink   = substr[3:4]
    minus    = int(substr[4:5])
     # segment_lengths = [7,1, 7, 1, 7, 1, 7, 1,7,17]
    digit1   = substr[0:7]
    dot1     = int(substr[7:8])
    digit2   = substr[8:15]
    dot2     = int(substr[15:16])
    digit3   = substr[16:23]
    dot3     = int(substr[23:24])
    digit4   = substr[24:31]
    
    print(digit1, dot1, digit2,dot2, digit3,dot3, digit4, sep=" ")


    micro    = int(substr[36:37])
    nano     = int(substr[37:38])
    kilo     = int(substr[38:39])
    diotst   = int(substr[39:40])
    mili     = int(substr[40:41])
    percent  = int(substr[41:42])
    mega     = int(substr[42:43])
    contst   = int(substr[43:44])
    cap      = int(substr[44:45])
    ohm      = int(substr[45:46])
    rel      = int(substr[46:47])
    hold     = int(substr[47:48])
    amp      = int(substr[48:49])
    volts    = int(substr[49:50])
    hertz    = int(substr[50:51])
    lowbat   = int(substr[51:52])
    minm     = int(substr[52:53])
    fahrenh  = substr[53:54]
    celcius  = int(substr[54:55])
    maxm     = int(substr[55:56])
     
    digit = {"1011111":"0",
             "1010111":"1",
             "1101100":"2",
             "1010111":"3",
             "1101010":"4",
             "1101110":"5",
             "0111111":"6",
             "1101100":"7",
             "1111111":"8",
             "1111110":"9",
             "0000000":"",
             "1101000":"L"}
     
    #value = ("-" if minus else " ") +\
    value = digit.get(digit1,"") + ("." if dot1 else "") +\
            digit.get(digit2,"") + ("." if dot2 else "") +\
            digit.get(digit3,"") + ("." if dot3 else "") +\
            digit.get(digit4,"")
 
    flags = " ".join(["AC"         if ac     else "",
                      "DC"         if dc     else "",
                      "Auto"       if auto   else "",
                      "Diode test" if diotst else "",
                      "Conti test" if contst else "",
                      "Capacity"   if cap    else "",
                      "Rel"        if rel    else "",
                      "Hold"       if hold   else "",
                      "Min"        if minm   else "",
                      "Max"        if maxm   else "",
                      "LowBat"     if lowbat else ""])
                      
    units = ("n"    if nano    else "") +\
            ("u"    if micro   else "") +\
            ("k"    if kilo    else "") +\
            ("m"    if mili    else "") +\
            ("M"    if mega    else "") +\
            ("%"    if percent else "") +\
            ("Ohm"  if ohm     else "") +\
            ("Amp"  if amp     else "") +\
            ("Volt" if volts   else "") +\
            ("Hz"   if hertz   else "") +\
            ("C"    if celcius else "")
        #
   # return value + " " + flags + " " + units
    return value


def find_differences(str1, str2):
    # Ensure both strings are of the same length
    if len(str1) != len(str2):
        raise ValueError("Both strings must be of the same length")

    # Find positions of different characters
    different_positions = []
    
    for i in range(len(str1)):
        if str1[i] != str2[i]:
            different_positions.append(i)
    
    return different_positions


def cut_out_characters(input_string):
    # Define the positions to cut out characters
    positions = [20, 21, 22, 24, 25, 26, 27]
    
    # Extract characters from the specified positions and join them into a new string
    extracted_characters = ''.join([input_string[pos] for pos in positions])
    
    return extracted_characters

def match_pattern(input_string):
    # Define the pattern dictionary
    pattern_dict = {
        "1111011": 0,
        "0001010": 1,
        "1011101": 2,
        "1001111": 3,
        "0101110": 4,
        "1100111": 5,
        "1110111": 6,
        "1001010": 7,
        "1111111": 8,
        "1101111": 9
    }
    
    # Match the input string with the pattern dictionary
    if input_string in pattern_dict:
        return pattern_dict[input_string]
    else:
        return None
     
     
sys.stderr.write('Press Ctrl+C to exit.\n\n')
prev_data = "10101110101111101011111001111111101100000000000000100000"
i =0
while 1:

    input("Press Enter to execute the function...")
    substr = get_bytes()
    #print(substr)
    #result = cut_out_characters(substr)
    #print(result)
    #print(match_pattern(result))

    #data = stream_decode(substr)
    print(substr)
    print(find_differences(substr, prev_data))
    prev_data = substr
    #print(data) 
    #if substr != prev_data:
    #    i = i+1
    #    prev_data = substr
        #print(substr)
        #print(find_differences(substr, prev_data))
        #port.flushInput()
        #data = stream_decode(substr)
        #display_string_table(substr)
        #print(add_spaces(substr))
        #print(i+"   "+substr) 
        #print(add_spaces(substr))
        #print(data) 
        #print(f"{i}{substr}")
    time.sleep(float(interval))
    port.flushInput()



#1110101 0 1101111 1 1111111 0 1111111 0 1111000 0000000000010000
#2.88