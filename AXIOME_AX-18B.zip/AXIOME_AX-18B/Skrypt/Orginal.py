#!/usr/bin/python2.7
 
#
#   Just a quick n' dirty script to read the Data from a VA18B multimeter.
#   This DMM uses the low nibble of 14 bytes to send the lcd segments.
#
#       License: GPL v3. http://www.gnu.org/licenses/gpl-3.0-standalone.html
#
 
import signal
import sys
import time
import serial
import io
import getopt
 
interval = '1.0'
device = '/dev/ttyUSB0'
 
 
def showhelp():
    print ("va18b.py -i <time in secs> -d <device>")
     
try:
    opts, args = getopt.getopt(sys.argv[1:],"hd:i:",['help'])
except getopt.GetoptError:
    print ("Error: -i, -d option require a value.")
    showhelp()
    sys.exit(1)
         
for opt, arg in opts:
    if opt in ('-h','--help'):
    #  showhelp()
      sys.exit(1)
    if opt == '-i':
      interval = arg
    if opt == '-d':
      device = arg
       
try:
    port=serial.Serial('COM38',
               baudrate=2400,
               bytesize=serial.EIGHTBITS,
               stopbits=serial.STOPBITS_ONE,
               parity=serial.PARITY_NONE,
               timeout=None)
     
    if not port.isOpen():
        port.open()
 
except IOError:
    #print '\nError:' + str(err) + '\n'
    sys.exit(1)
 
 
def signal_handler(signal, frame):
        sys.stderr.write('\n\nYou pressed Ctrl+C!\n\n')
        port.flushInput()
        port.close()
        sys.exit(0)
         
signal.signal(signal.SIGINT, signal_handler)
 
# Every packet is 14 bytes long.
def get_bytes():
    i=0
    substr=''
    while i<=13:
        byte=port.read(1)
        # converting every byte to binary format keeping the low nibble.
        substr += '{0:08b}'.format(ord(byte))[4:]
        i += 1
    return substr
       
 
def stream_decode(substr):
   #positions = [20, 21, 22, 24, 25, 26, 27]
    
    auto     = int(substr[1:2])
    dc       = int(substr[2:3])
    ac       = int(substr[3:4])

    
    pclink   = substr[3:4]
    minus    = int(substr[7:8])

    digit1_pos = [4,5,6,8,9,10,11]
    digit2_pos = [12,13,14,16,17,18,19]
    digit3_pos = [20,21,22,24,25,26,27]
    digit4_pos = [28,29,30,32,33,34,35]

    dot1     = int(substr[15:16])
    dot2     = int(substr[23:24])
    dot3     = int(substr[31:32])
    
    digit1 = ''.join([substr[pos] for pos in digit1_pos])
    digit2 = ''.join([substr[pos] for pos in digit2_pos])
    digit3 = ''.join([substr[pos] for pos in digit3_pos])
    digit4 = ''.join([substr[pos] for pos in digit4_pos])


    #print(digit1 +" "+ digit2 +" "+ digit3 +" "+ digit4)

    micro    = int(substr[39:40])#Ok

    cap     = int(substr[47:48])   
    nano      = int(substr[38:39]) #?


    diotst   = int(substr[36:37]) #OK
    lowbat   = int(substr[48:49]) #OK
    kilo     = int(substr[37:38]) #Ok
    mili     = int(substr[43:44]) #ok
    percent  = int(substr[42:43]) #Ok
    mega     = int(substr[41:42]) #Ok
    contst   = int(substr[40:41]) #Ok
    ohm      = int(substr[46:47]) #Ok
    rel      = int(substr[45:46]) #Ok
    hold     = int(substr[44:45]) #ok
    amp      = int(substr[51:52]) #Ok
    volts    = int(substr[50:51]) #Ok
    hertz    = int(substr[49:50]) #Ok
    ncv      = int(substr[52:53]) #Ok
    fahrenh  = int(substr[55:56]) #Ok
    celcius  = int(substr[54:55]) #Ok
   
     
    value = ("-" if minus else "")+match_pattern(digit1) + ("." if dot1 else "") + match_pattern(digit2) + ("." if dot2 else "") + match_pattern(digit3) + ("." if dot3 else "") + match_pattern(digit4)

    #print(value)         
            
            
 
    flags = " ".join(["AC"         if ac     else "",
                      "DC"         if dc     else "",
                      "Auto"       if auto   else "",
                      "Diode test" if diotst else "",
                      "Conti test" if contst else "",
                      "Capacity"   if cap    else "",
                      "Rel"        if rel    else "",
                      "Hold"       if hold   else "",
                      "ncv"         if ncv else "",
                      "LowBat"     if lowbat else ""])
                      
    units = ("n"    if nano    else "") +\
            ("u"    if micro   else "") +\
            ("k"    if kilo    else "") +\
            ("m"    if mili    else "") +\
            ("M"    if mega    else "") +\
            ("%"    if percent else "") +\
            ("Ohm"  if ohm     else "") +\
            ("Amp"  if amp     else "") +\
            ("Volt" if volts   else "") +\
            ("Hz"   if hertz   else "") +\
            ("F"   if fahrenh   else "") +\
            ("C"    if celcius else "")
            
    return value + " " + flags + " " + units
    #return value
     
sys.stderr.write('Press Ctrl+C to exit.\n\n')
 

def match_pattern(input_string):
    # Define the pattern dictionary
    pattern_dict = {
        "1111011": "0",
        "0001010": "1",
        "1011101": "2",
        "1001111": "3",
        "0101110": "4",
        "1100111": "5",
        "1110111": "6",
        "1001010": "7",
        "1111111": "8",
        "1101111": "9",
        "0110001":"L",
        "1110101":"E",
        "1000101":"F",
        "0000100": "-",
        "0000000": ""
    }
    
    # Match the input string with the pattern dictionary
    if input_string in pattern_dict:
        return pattern_dict[input_string]
    else:
        return ""
def get_value(input_string):
    result = 0 
    return result
def get_unit(input_string):
    result = 0
    return result
def get_range(input_string):
    result = 0
    return result

while 1:
    substr = get_bytes()
    data = stream_decode(substr)
    print(substr)
    print (data)
    time.sleep(float(interval))
    port.flushInput()