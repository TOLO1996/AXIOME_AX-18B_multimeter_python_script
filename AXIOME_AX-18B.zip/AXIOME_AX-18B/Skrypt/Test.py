def find_differences(str1, str2):
    # Ensure both strings are of the same length
    if len(str1) != len(str2):
        raise ValueError("Both strings must be of the same length")

    # Find positions of different characters
    different_positions = []
    
    for i in range(len(str1)):
        if str1[i] != str2[i]:
            different_positions.append(i)
    
    return different_positions

# Example usage
str1 = "10000000000011101011011000010001000000000000001000000000"
str2 = "10000000000011111011011000010000000001000000001000000000"

different_positions = find_differences(str1, str2)

print(f"Different Positions: {different_positions}")

input_string = "10101110101111101011000010101111101100000000000000100000"



def cut_out_characters_digit1(input_string):
    # Define the positions to cut out characters
    positions = [4, 5, 6, 8, 9, 10, 11]
    
    # Extract characters from the specified positions and join them into a new string
    extracted_characters = ''.join([input_string[pos] for pos in positions])
    
    return extracted_characters
def cut_out_characters_digit2(input_string):
    # Define the positions to cut out characters
    positions = [12, 13, 14, 16, 17, 18, 19]
    
    # Extract characters from the specified positions and join them into a new string
    extracted_characters = ''.join([input_string[pos] for pos in positions])
    
    return extracted_characters

def cut_out_characters_digit3(input_string):
    # Define the positions to cut out characters
    positions = [20, 21, 22, 24, 25, 26, 27]
    
    # Extract characters from the specified positions and join them into a new string
    extracted_characters = ''.join([input_string[pos] for pos in positions])
    
    return extracted_characters
def cut_out_characters_digit4(input_string):
    # Define the positions to cut out characters
    positions = [28, 29, 30, 32, 33, 34, 35]
    
    # Extract characters from the specified positions and join them into a new string
    extracted_characters = ''.join([input_string[pos] for pos in positions])
    
    return extracted_characters

def match_pattern(input_string):
    # Define the pattern dictionary
    pattern_dict = {
        "1111011": 0,
        "0001010": 1,
        "1011101": 2,
        "1001111": 3,
        "0101110": 4,
        "1100111": 5,
        "1110111": 6,
        "1001010": 7,
        "1111111": 8,
        "1101111": 9
    }
    
    # Match the input string with the pattern dictionary
    if input_string in pattern_dict:
        return pattern_dict[input_string]
    else:
        return None

# Input string
input_string = '10101110101111101011111010111110111100000000000000100000'

# Call the function and store the result in a separate variable
digit1 = cut_out_characters_digit1(input_string)
digit2 = cut_out_characters_digit2(input_string)
digit3 = cut_out_characters_digit3(input_string)
digit4 = cut_out_characters_digit4(input_string)
#print(f"Extracted characters: {result}")
print(digit1, digit2,  digit3,  digit4)
print(match_pattern(digit1),match_pattern(digit2),match_pattern(digit3),match_pattern(digit4))
